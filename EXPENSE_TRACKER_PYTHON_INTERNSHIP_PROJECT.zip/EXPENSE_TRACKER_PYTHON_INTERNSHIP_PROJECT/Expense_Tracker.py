import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3
from datetime import datetime

class ExpenseTracker:
    def __init__(self, root):
        self.root = root
        self.root.title("Expense Tracker")
        self.root.resizable(0,0)

        # Creating expense table:
        self.conn = sqlite3.connect("EXPENSE.db")
        self.cursor = self.conn.cursor()
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS expenses (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                amount REAL,
                category TEXT,
                notes TEXT,
                date TEXT
            )
        ''')
        self.conn.commit()
        
        #creating labels and entry with packing:

        self.amount_label = tk.Label(root, text="Amount:" , bg = "slategrey" , fg = "black", borderwidth =5)
        self.amount_label.grid(row=0, column=0, padx=5, pady=5)
        self.amount_entry = tk.Entry(root , fg = "black" , bg = "slategrey" , width = 20 , borderwidth = 5 )
        self.amount_entry.grid(row=0, column=1, padx=5, pady=5)

        self.category_label = ttk.Label(root, text="Category:", borderwidth =5)
        self.category_label.grid(row=1, column=0, padx=5, pady=5)
        self.category_combobox = ttk.Combobox(root , values=["Groceries", "Entertainment","Recharges","Travel","clothing","Medical needs", "Others"])
        self.category_combobox.grid(row=1, column=1, padx=5, pady=5)

        self.notes_label = tk.Label(root, text="Notes:", bg = "slategrey" , fg = "black", borderwidth =5)
        self.notes_label.grid(row=2, column=0, padx=5, pady=5)
        self.notes_entry = tk.Entry(root , fg = "black" , bg = "slategrey" , width = 20 , borderwidth = 5 )
        self.notes_entry.grid(row=2, column=1, padx=5, pady=15)

        self.add_button = tk.Button(root, text="Add Expense", command=self.add_expense, bg = "midnightblue" , fg = "white" , borderwidth =5 , border = 5)
        self.add_button.grid(row=3, column=1, columnspan=2 , padx = 20)

        self.expense_tree = ttk.Treeview(root, columns=("ID", "Amount", "Category", "Notes", "Date"), show="headings" )
        self.expense_tree.heading("ID", text="ID")
        self.expense_tree.heading("Amount", text="Amount")
        self.expense_tree.heading("Category", text="Category")
        self.expense_tree.heading("Notes", text="Notes")
        self.expense_tree.heading("Date", text="Date")
        self.expense_tree.grid(row=6, column=0, columnspan=2, padx= 30 , pady=20)

        # Load expenses:
        self.load_expenses()

    def add_expense(self):
        try:
            amount = float(self.amount_entry.get())
            if amount <= 0:
                raise ValueError("Amount must be greater than 0.")
            
            category = self.category_combobox.get()
            notes = self.notes_entry.get()
            date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

            # Insert to database:
            self.cursor.execute('''
                INSERT INTO expenses (amount, category, notes, date)
                VALUES (?, ?, ?, ?)
            ''', (amount, category, notes, date))
            self.conn.commit()
            # Update UI
            self.load_expenses()
            messagebox.showinfo("Success", "Expense added successfully!")

        except ValueError as ve:
            messagebox.showerror("Error", str(ve))
        except Exception as e:
            messagebox.showerror("Error", f"An unexpected error occurred: {str(e)}")

    def load_expenses(self):
        # Clear existing data in the treeview
        for item in self.expense_tree.get_children():
            self.expense_tree.delete(item)

        # Fetch and display expenses from the database
        self.cursor.execute("SELECT * FROM expenses")
        expenses = self.cursor.fetchall()

        for expense in expenses:
            self.expense_tree.insert("", "end", values=expense)

if __name__ == "__main__":
    root = tk.Tk()
    app = ExpenseTracker(root)
    root["background"] = "darkturquoise"
    root.mainloop()
