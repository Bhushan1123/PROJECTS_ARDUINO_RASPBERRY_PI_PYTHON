import tkinter as tk
from tkinter import ttk
import sqlite3

class FoodDonationTracker:
    def __init__(self, root):
        self.root = root
        self.root.title("Food Donation Tracker")

        # Create SQLite database
        self.conn = sqlite3.connect('food_donations.db')
        self.create_table()

        # GUI Components
        self.name_label = tk.Label(root, text="Donor Name:   ",bg="slategray",fg="black",borderwidth=5)
        self.name_entry = tk.Entry(root, width=30,borderwidth=5,bg="slategray",fg="white")

        self.food_label = tk.Label(root, text="Food Item:     ",bg="slategray",fg="black",borderwidth=7)
        self.food_entry = tk.Entry(root, width=30,borderwidth=5,bg="slategray",fg="white")

        self.quantity_label = tk.Label(root, text="Quantity:     ",bg="slategray",fg="black",borderwidth=10)
        self.quantity_entry = tk.Entry(root, width=30,borderwidth=5,bg="slategray",fg="white")

        self.add_button = tk.Button(root, text="Add Donation", command=self.add_donation,bg="black",fg="white",borderwidth=5)

        # Treeview for displaying donations
        self.tree = ttk.Treeview(root, columns=('ID','donor_name', 'food_item', 'quantity'), show="headings")
        self.tree.heading('ID', text='ID')
        self.tree.heading('donor_name', text='Donor Name')
        self.tree.heading('food_item', text='Food Item')
        self.tree.heading('quantity', text='Quantity')
        self.show_donations()

        # Grid layout
        self.name_label.grid(row=0, column=0, padx=30, pady=20, sticky=tk.W)
        self.name_entry.grid(row=0, column=1, padx=10, pady=20)

        self.food_label.grid(row=1, column=0, padx=30, pady=0, sticky=tk.W)
        self.food_entry.grid(row=1, column=1, padx=10, pady=0)

        self.quantity_label.grid(row=2, column=0, padx=30, pady=20, sticky=tk.W)
        self.quantity_entry.grid(row=2, column=1, padx=10, pady=20)

        self.add_button.grid(row=3, column=1, columnspan=2, pady=0)

        self.tree.grid(row=4, column=0, columnspan=2, padx=30, pady=20)

        root.protocol("WM_DELETE_WINDOW", self.on_closing)

    def create_table(self):
        cursor = self.conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS donations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                donor_name TEXT,
                food_item TEXT,
                quantity INTEGER
            )
        ''')
        self.conn.commit()

    def add_donation(self):
        donor_name = self.name_entry.get()
        food_item = self.food_entry.get()
        quantity = self.quantity_entry.get()

        if donor_name and food_item and quantity:
            cursor = self.conn.cursor()
            cursor.execute('''
                INSERT INTO donations (donor_name, food_item, quantity)
                VALUES (?, ?, ?)
            ''', (donor_name, food_item, quantity))
            self.conn.commit()

            # Clear entry fields
            self.name_entry.delete(0, tk.END)
            self.food_entry.delete(0, tk.END)
            self.quantity_entry.delete(0, tk.END)

            # Update Treeview
            self.show_donations()

    def show_donations(self):
        cursor = self.conn.cursor()
        cursor.execute('SELECT * FROM donations')
        rows = cursor.fetchall()

        # Clear existing items in the treeview
        for item in self.tree.get_children():
            self.tree.delete(item)

        # Insert new data into the treeview
        for row in rows:
            self.tree.insert('', 'end', values=row)

    def on_closing(self):
        self.conn.close()
        self.root.destroy()

if __name__ == "__main__":
    root = tk.Tk()
    app = FoodDonationTracker(root)
    root["background"]="indigo"
    root.mainloop()
