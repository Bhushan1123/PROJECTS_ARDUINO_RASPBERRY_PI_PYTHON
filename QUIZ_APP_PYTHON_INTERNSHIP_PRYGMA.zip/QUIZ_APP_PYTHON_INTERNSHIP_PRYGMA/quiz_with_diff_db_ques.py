from tkinter import *
import tkinter as tk
from tkinter import messagebox
import sqlite3
from questions import questions
from datetime import datetime

connection = sqlite3.connect("quiz.db")
cursor = connection.cursor()
connection.execute('''
   CREATE TABLE IF NOT EXISTS student_data(
       student_name TEXT NOT NULL,
       student_prn TEXT  NOT NULL,
       score TEXT NOT NULL,
       date_time TEXT NOT NULL            
   )
''')
class QuizApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Quiz App")
        root.geometry("750x450")
        self.x = 0
        root.resizable(0,0)
        # Quiz variables
        self.score = 0
        self.questions = self.load_questions()
        
        self.date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # GUI elements
        self.Go = tk.Button(root, text = "LOGIN", command=self.student_info,width = 18 , height = 2 ,font =("Arial bold",16), bg = "blueviolet" , fg = "white" , borderwidth = 10 )
        self.Go.pack(padx = 20 , pady = 20 , side="right" , fill="x" , anchor = "se")
    
    def start_quiz(self):
        self.label_question = tk.Label(root, text="" , font = 16 ,borderwidth = 10, bg = "black" , fg = "white")
        self.label_question.pack(pady = 20)

        self.var_option = tk.IntVar()
        self.var_option.set(-1)  # Default value
        # Check if student name and PRN are entered
        if not self.student_name.get() or not self.student_prn.get():
            messagebox.showwarning("Warning", "Please enter your name and PRN.")
        else:
            # Hide student info elements and show quiz elements
            self.label_name.pack_forget()
            self.entry_name.pack_forget()
            self.label_prn.pack_forget()
            self.entry_prn.pack_forget()
            self.btn_start_quiz.pack_forget()
            self.radio_option1 = tk.Radiobutton(root, text="", variable=self.var_option, value=1 , font = 14 , bg = "skyblue" , fg = "black")
            self.radio_option1.pack(padx=10, pady=15)

            self.radio_option2 = tk.Radiobutton(root, text="", variable=self.var_option, value=2, font = 14 , bg = "skyblue" , fg = "black")
            self.radio_option2.pack(padx=10, pady=15)

            self.radio_option3 = tk.Radiobutton(root, text="", variable=self.var_option, value=3, font = 14 , bg = "skyblue" , fg = "black")
            self.radio_option3.pack(padx=10, pady=15)

            self.radio_option4 = tk.Radiobutton(root, text="", variable=self.var_option, value=4, font = 14 , bg = "skyblue" , fg = "black")
            self.radio_option4.pack(padx=10, pady=15)

            self.btn_next = tk.Button(root, text="Next", command=self.next_question,bg = "limegreen" , font=("Arial bold",12) ,fg="black" ,  width=20, height=3)
            self.btn_next.pack(padx=20, pady=10 , side = "left" , fill = "x" , anchor = "w")

            self.btn_submit = tk.Button(root, text="Submit", command=self.submit_quiz, state=tk.DISABLED,
                                    width=20, height=3, bg="indianred", fg="black", font=("Arial bold",12))
            self.btn_submit.pack(padx=20, pady=20, side="right", fill="x" , anchor = "e")

        # Start the quiz
        self.load_next_question()

    def load_questions(self):
        return questions

    def load_next_question(self):
        if self.x < len(self.questions):
            y = self.questions[self.x]
            self.label_question.config(text = y["question_text"])
            self.radio_option1.config(text = y["options"][0])
            self.radio_option2.config(text = y["options"][1])
            self.radio_option3.config(text = y["options"][2])
            self.radio_option4.config(text = y["options"][3])
            self.var_option.set(-1)  # Reset radio button selection
        else:
            self.show_results()

    def next_question(self):
        # Check if an option is selected
        if self.var_option.get() == -1:
            messagebox.showwarning("Warning", "Please select an option.")
        else:
            # Check if the selected option is correct
            y = self.questions[self.x]
            if self.var_option.get() == y["correct_option"]:
                self.score += 1
            # Move to the next question
            self.x +=1
            self.load_next_question()

    def show_results(self):
        messagebox.showinfo("Quiz Completed", f"You have completed the quiz!\nYour Score: {self.score}/{len(self.questions)}")
        self.btn_submit.config(state=tk.NORMAL)

    def submit_quiz(self):
        # You can add more functionality here, such as storing the user's score in a database
        messagebox.showinfo("Quiz Submitted", f"Your final score is: {self.score}")
        connection = sqlite3.connect('quiz.db')
        cursor = connection.cursor()
        record = (self.student_name.get(), self.student_prn.get() , self.score , self.date)
        insert_query = "INSERT INTO student_data (student_name,student_prn ,score , date)VALUES (?,?,?,?)"
        cursor.execute(insert_query, record)
        connection.commit()
        cursor.close()
        self.root.destroy()

    def student_info(self):
        label_1.pack_forget()
        self.student_name = tk.StringVar()
        self.student_prn = tk.StringVar()

        self.label_name = tk.Label(root, text="Enter Your Name:",fg = "white",bg ="dimgray",font = "BOLD" , width = 15 ,height = 1)
        self.label_name.pack(padx = 50 , pady = 10 , side = "top" , anchor  = "w" )

        self.entry_name = tk.Entry(root, textvariable=self.student_name,bg = "lightcyan" , width = 25 , insertwidth = 10 ,borderwidth = 8 )
        self.entry_name.pack(pady = 0 , padx = 50 , side = "top" , fill = "x")

        self.label_prn = tk.Label(root, text="Enter Your PRN:",fg = "white",bg = "dimgray",font = "BOLD" , width = 15 ,height = 1)
        self.label_prn.pack(padx = 50 , pady = 10 , side = "top" , anchor  = "w")
        
        self.entry_prn = tk.Entry(root, textvariable=self.student_prn,bg = "lightcyan" , width = 25 , insertwidth = 10 , borderwidth = 8)
        self.entry_prn.pack(pady = 0 , padx = 50 , side = "top" , fill = "x")

        self.btn_start_quiz = tk.Button(root, text="Start Quiz",width = 20,height = 2 , fg = "white",bg = "slateblue",font = "BOLD", command=self.start_quiz)
        self.btn_start_quiz.pack(pady = 20 , side = "bottom"  )
 
        self.Go.pack_forget()

if __name__ == "__main__":
    root = tk.Tk()
    app = QuizApp(root)
    img = PhotoImage(file = "TC1.png")
    label_1 = Label(root , image = img )
    label_1.pack( fill = "y" ,padx = 20 , pady = 20 , side = "left" )
    root["background"] = "skyblue"
    root.mainloop()